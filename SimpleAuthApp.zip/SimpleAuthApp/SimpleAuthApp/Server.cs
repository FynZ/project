﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SimpleAuthApp
{
    public enum Server
    {
        Meriana,
        Agride,
        Nidas,
        Brumen,
        Merkator,
        Furye,
        Julith,
        Ush,
        Pandora
    }
}
